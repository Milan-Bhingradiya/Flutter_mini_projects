enum ImageLocation { photos, files }
