import 'package:flutter/material.dart';

abstract class ThemeText {
  static const TextStyle menuItem = TextStyle(fontWeight: FontWeight.w400, fontSize: 14);
}
