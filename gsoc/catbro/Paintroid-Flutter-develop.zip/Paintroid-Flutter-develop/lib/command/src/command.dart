import 'package:equatable/equatable.dart';

abstract class Command with EquatableMixin {
  const Command();
}
